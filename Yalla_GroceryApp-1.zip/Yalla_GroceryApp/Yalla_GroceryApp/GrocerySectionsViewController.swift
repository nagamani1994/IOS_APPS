//
//  GrocerySectionsViewController.swift
//  Yalla_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return varB_GroceryAppArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var GroceryApp_cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        GroceryApp_cell.textLabel?.text = varB_GroceryAppArray[indexPath.row].section
        return GroceryApp_cell
    }
    
    var varA_GroceryApp = Grocery()
    
    var varB_GroceryAppArray = grocery_ItemList_GroceryApp

    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.title = "Grocery Sections"
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition_GroceryyApp = segue.identifier
        if transition_GroceryyApp == "itemSegue"{
            let destination_GroceryyApp = segue.destination as! GroceryItemsViewController
            destination_GroceryyApp.items = varB_GroceryAppArray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
        }
    }


}

