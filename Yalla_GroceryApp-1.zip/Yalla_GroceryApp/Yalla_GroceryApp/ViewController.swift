//
//  ViewController.swift
//  Yalla_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

